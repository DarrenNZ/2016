// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP 102 Assignment 3 
 * Name:
 * Usercode:
 * ID:
 */

import ecs100.*;

/** Program to create simple animated cartoon strips using the
 *  CartoonFigure class.  
 */

public class CartoonStrip{

    /** animate creates two cartoon figures on the window.
     *  Then animates them according to a fixed script by calling a series
     *  of methods on the figures.
     */
    public void animate(){
        /*# YOUR CODE HERE */
    
    }

    /** For the completion, the story must be a gamebook story
     *      where the user is asked to make decisions about what the characters will do.
     *   At the end it must print out the users power bill for the story that they chose.
     */
    public void animateCompletion(){
        UI.clearPanes();
        /*# YOUR CODE HERE */
    
    }

    /** ---------- The code below is already written for you ---------- **/
        /** Constructor: set up user interface */
    public CartoonStrip(){
        UI.initialise();
        UI.addButton("Clear", UI::clearGraphics );
        UI.addButton("Animate", this::animate );
        UI.addButton("Animate Completion", this::animateCompletion );
        UI.addButton("Quit", UI::quit );
        UI.setDivider(0);       // Expand the graphics area
    }


}

